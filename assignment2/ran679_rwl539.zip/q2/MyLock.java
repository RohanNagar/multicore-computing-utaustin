package q2;

public interface MyLock{
    public void lock(int myId);
    public void unlock(int myId);
}

To compile both parts, run `make`.

To run part A, use the command: `./matrix FILE1 FILE2 NUM_THREADS`

To run part B, use the command: `./MonteCarlo NUM_SAMPLES`
